clear all
clc
x=[0 4 8 12 16 20];
y=[67.38 74.67 82.74 91.69 101.60 112.58];
% Linear regression
figure(1)
[a1,r2_1]=linregr(x,y);
title('Linear regression');
r2_1
% Polynomial regression
a2=HW4_15_4(x,y,2);
p_2=@(t) a2(3)*t.^2+a2(2)*t+a2(1);
figure(2)
plot(x,y,'o','MarkerFaceColor','g','MarkerEdgeColor','k')
hold on
plot(x,p_2(x),'r')
title('Polynomial regression');
hold off
grid on
sd=sum((y-mean(y)).^2);
resd=sum((y-(p_2(x))).^2);
r2_2=(sd-resd)/sd
% Exponential model
a3=fminsearch(@fSSR2,[1,1],[],x,y);
exn=@(s) a3(1)*exp(a3(2)*s);
figure(3)
plot(x,y,'o','MarkerFaceColor','r','MarkerEdgeColor','k')
hold on
plot(x,exn(x),'k--')
title('Exponential regression');
hold off
grid on
resd_e=sum((y-(exn(x))).^2);
r2_3=(sd-resd_e)/sd


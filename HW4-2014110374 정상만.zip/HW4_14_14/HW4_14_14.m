% bacteria K and oxygen concentration C
c=[0.5 0.8 1.5 2.5 4];
k=[1.1 2.5 5.3 7.6 8.9];
% slope, intercept
x=1./c.^2; y=1./k; n=5;
bar_x=mean(x); bar_y=mean(y);
a1=(n*sum(x.*y)-sum(x)*sum(y))/(n*sum(x.^2)-(sum(x))^2);
a0=bar_y-a1*bar_x;
k_max=1/a0;
Cs=a1*k_max;
% Linear regression
y_hat=@(t) k_max*((t.^2)./(Cs+t.^2));
ct=0:0.1:5;
scatter(c,k,'MarkerFaceColor','r','MarkerEdgeColor','r');
hold on
plot(ct,y_hat(ct),'k');
title('Linear regression of use the linearized equation')
xlabel('c'); ylabel('k');
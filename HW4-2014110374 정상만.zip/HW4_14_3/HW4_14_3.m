D=[29.65 28.55 28.65 30.15 29.35 29.75 29.25 30.65 28.15 29.85 29.05 30.25 30.85 28.75 29.65 30.45 29.15 30.45 33.65 29.35 29.75 31.25 29.45 30.15 29.65 30.55 29.65 29.25];
% a) mean (���)
m=mean(D);
% b) median (�߾Ӱ�)
me=median(D);
% c) mode (�ֺ�)
frq=mode(D);
% d) range (����)
ran=range(D);
% e) standard deviation (ǥ������)
s=std(D);
% f) variance (�л�)
var=s^2;
% g) coefficient of variation
cv=s/m;
% h) histogram, range : 28 to 34 and increments : 0.4
inc=28:0.4:34;
hist(D);
% i) 68% of the readings
a=m-s; b=m+s;
I=D(D>a & D<b);
p=length(I)/length(D);
% the list of the results of a)~i)
A=[m me frq ran s var cv p]';

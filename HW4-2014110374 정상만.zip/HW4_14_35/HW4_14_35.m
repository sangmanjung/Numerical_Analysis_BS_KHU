clear all
clc
% initial value
v0=25;
y0=1;
theta0=(50*pi)/180;
g=9.81;
% Monte Carlo equation
fn=@(t) tan(theta0)*t-((g*t.^2)/(2*(v0^2)*cos(theta0)^2))+y0;
% a) the maximum height (analytically)
max_x1=((v0^2)*(tan(theta0)*cos(theta0)^2))/g;
% b) the maximum height (numerically)
x=linspace(0,60,10000);
y=fn(x);
max(y);
plot(x,y,'k');
for i=1:length(x);
 max_x2=x(i);   
end
max_x2=x(find(fn(x)==max(y)));
hold on
plot(max_x2,fn(max_x2),'o','MarkerFaceColor','r','MarkerEdgeColor','r');
title('The maximum value of Monte Carlo equation from 0m to 60m');
xlabel('x-axis'); ylabel('y-axis');

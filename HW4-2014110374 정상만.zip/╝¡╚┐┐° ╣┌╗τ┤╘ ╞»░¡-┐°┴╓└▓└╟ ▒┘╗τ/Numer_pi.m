clear all
clc
% Numerical solution of pi
N=10000;
N_inner=0;
for i=1:N;
    x=rand(N,1);
    y=rand(N,1);
if x(i)^2+y(i)^2 < 1, N_inner=N_inner+1; end
end
N_total=N;
Numerical_pi=4*(N_inner/N_total);
disp('Numerical Solution of Pi is')
disp(Numerical_pi)
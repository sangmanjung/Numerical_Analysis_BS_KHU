% a) Linearize
S=[0.01 0.05 0.1 0.5 1 5 10 50 100];
v0=[6.078e-11 7.595e-9 6.063e-8 5.788e-6 1.737e-5 2.423e-5 2.430e-5 2.431e-5 2.431e-5];
ap=1./S.^3;
bt=1./v0;
a=linregr(ap,bt);
Km=1/a(2);
K=Km*a(1);
format long
A=[Km K]
% Plot
v0p=Km*S.^3./(K+S.^3);
figure(1)
loglog(S,v0,'o','MarkerFaceColor','r','MarkerEdgeColor','r')
hold on
loglog(S,v0p,'k')
title('Linear regression');
hold off
% b) Nonlinear regression
format long
a1=fminsearch(@fSSR, [2e-5, 1], [], S, v0)
v0p1 = a1(1)*S.^3./(a1(2)+S.^3);
% Plot
figure(2)
loglog(S,v0,'o','MarkerFaceColor','k','MarkerEdgeColor','k')
hold on
loglog(S,v0p1,'b')
title('Nonlinear regression');
hold off

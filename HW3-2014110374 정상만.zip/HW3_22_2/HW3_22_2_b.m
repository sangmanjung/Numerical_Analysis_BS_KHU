%Euler's method in HW3, 22.2
clear all
clc
h=0.25;
x=0:h:1;
N=floor(1/h);
y1(1)=1;
for i=1:N;
    y1(i+1)=y1(i)+sqrt(y1(i))*h;
end
y1

clear all
x=[0 0.25 0.5 0.75 1];
y=@(t) (((2*t.^2)+t+2).^2)/2^2;
y(x);
A=[x ; y(x)];
fprintf('x               y\n')
fprintf('%1.3f           %1.8f\n',A)

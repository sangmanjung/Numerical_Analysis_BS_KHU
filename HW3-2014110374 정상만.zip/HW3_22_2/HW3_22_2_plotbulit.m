dydx = @(x,y) (1+4*x)*sqrt(y);
h = 0.25;
y = @(x) ((2*(x).^2 + x + 2)/2).^2;
 
% (a) Exact solution
figure(1)
fplot(y,[0 1])
hold on, grid on
% (b) Euler method
[tp, yp] = eulersys(dydx,[0 1],1, 0.25)
plot(tp,yp)
% (c) Heun's method
[t,y] = Heun(dydx,[0 1],1,h)
plot(t,y)
% (d) Ralston��s method.
[tp,yp] = ralstons(dydx,[0 1],1,h)
plot(tp,yp)
% (e) Runge-Kutta 4th order method
[tp,yp] = rk4sys(dydx,[0 1],1,h)
plot(tp,yp)
title('Solve the ODE as Numerical method')
legend('Exact','Euler', 'Heuns','Ralstons','RK4');
hold off
clear all
clc
format long
[x y]=rk4sys(@dydxsys,[0 1],1,0.25);
disp('      x         y') 
disp('   -----------------')
disp([x' y(:,1)])
 
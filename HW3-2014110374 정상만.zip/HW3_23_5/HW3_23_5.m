%Euler's method in HW3, 23.5
clear all
clc
h=0.1;
x=0:h:2;
N=floor(1/h);
y(1)=0;
x(1)=0;
for i=1:2*N;
    y(i+1)=y(i)+(-100000*y(i)+99999*exp(-x(i)))*h;
    y1(i+1)=(y(i+1)+99999*exp(-x(i+1))*h)/(1+100000*h);
end
format long
y1'
plot(x,y1)

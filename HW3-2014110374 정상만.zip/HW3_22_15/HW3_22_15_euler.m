clear all
clc
%initial conditions
global cm km
k=20; m=20; c(1)=5; c(2)=40; c(3)=200; km=k/m
tspan=[0 15];
y0=[0 1];
for i=1:3;
    cm=c(i)/m;
dxdtsys=@(t,x) [-(cm)*x(1)-(km)*x(2);x(1)];
[t x]=ode45(dxdtsys,tspan,y0);
plot(t,x(:,2));
xlabel('Times (s)'); ylabel('Displacement (x)');
legend('c=5','c=40','c=200');
hold on
end


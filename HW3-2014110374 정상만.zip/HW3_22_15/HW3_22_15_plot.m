fh=@HW3_22_15;
fplot(fh,[0 15]);
title('The motion of a damped spring-mass system');
xlabel('times (t)');
ylabel('displacement (x)');
legend('c=5','c=40','c=200');

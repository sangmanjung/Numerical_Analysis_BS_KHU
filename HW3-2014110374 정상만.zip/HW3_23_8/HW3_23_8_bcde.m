clear all
clc
%ODE
dydt=@(t,y) 5*(y-(t).^2);
%constant
t=0:0.1:5;
t_span=[0 5];
h=0.03125;
y0=0.08;
% a) Exact solution
y1=@(t) t.^2-(2/5)*t-(2/25)+0.16;
figure(5)
plot(t,y1(t))
%Numerical solution
% b) rk4sys
[t y2]=rk4sys(dydt,t_span,y0,h);
figure(1)
plot(t,y2,'r')
% c) ode45
[t,y]=ode45(dydt,t_span,y0);
figure(2)
plot(t,y,'b')
% d) ode23s
[t,y]=ode23s(dydt,t_span,y0);
figure(3)
plot(t,y,'k')
% e) ode23tb
[t,y]=ode23tb(dydt,t_span,y0);
figure(4)
plot(t,y,'g')




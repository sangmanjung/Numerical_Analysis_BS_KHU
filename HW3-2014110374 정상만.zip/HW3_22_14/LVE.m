function yp = LVE(t,y)
a=0.23; b=0.0133; c=0.4; d=0.0004;
yp = [a*y(1)-b*y(1)*y(2);-c*y(2)+d*y(1)*y(2)];
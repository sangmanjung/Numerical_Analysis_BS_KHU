function yo=HW3_23_10_ii(t,theta)
g=9.81; l=0.6;
yo=[theta(2);-(g/l)*theta(1)];
clear all
clc

%Initial conditions
tspan=[0 20];
theta0_1=[pi/8 0];
theta0_2=[pi/2 0];

%Nonlinear models : theta=pi/8, theta=pi/2
[tn8 thetan8]=ode45(@HW3_23_10_i,tspan,theta0_1);
[tn2 thetan2]=ode45(@HW3_23_10_i,tspan,theta0_2);

%Linear models : theta=pi/8, theta=pi/2
[tl8 thetal8]=ode45(@HW3_23_10_ii,tspan,theta0_1);
[tl2 thetal2]=ode45(@HW3_23_10_ii,tspan,theta0_2);


%Perspective
subplot(2,1,1);plot(tn8,thetan8(:,1),tl8,thetal8(:,1),'--');
legend('nonlinear','linear');
title('(1) theta=pi/8');
subplot(2,1,2);plot(tn2,thetan2(:,1),tl2,thetal2(:,1),'--');
legend('nonlinear','linear');
title('(2) theta=pi/2');


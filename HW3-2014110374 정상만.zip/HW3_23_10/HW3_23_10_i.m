function yp=HW3_23_10_i(t,theta)
g=9.81; l=0.6;
yp=[theta(2);-(g/l)*sin(theta(1))];
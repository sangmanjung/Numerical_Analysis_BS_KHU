function root = falsepos(func,xl,xu,es,maxit)
% falsepos(func,xl,xu,es,maxit):
% uses the false position method to find the root
% of the function func
% input:
% func = name of function
% xl, xu = lower and upper guesses
% es = (optional) stopping criterion (%) (default = 0.001)
% maxit = (optional) maximum allowable iterations (default = 50)
% output:
% root = real root
if func(xl)*func(xu)>0 %if guesses do not bracket a sign change
error('no bracket') %display an error message and terminate
end
% default values
if nargin<5, maxit=50; end
if nargin<4, es=0.001; end
% false position
iter = 0;
xr = xl;
while (1)
xrold = xr;
xr = xu - func(xu)*(xl - xu)/(func(xl) - func(xu));
iter = iter + 1;
if xr ~= 0, ea = abs((xr - xrold)/xr) * 100; end
test = func(xl)*func(xr);
if test < 0
xu = xr;
elseif test > 0
xl = xr;
else
ea = 0;
end
if ea <= es | iter >= maxit, break, end
end
root = xr;

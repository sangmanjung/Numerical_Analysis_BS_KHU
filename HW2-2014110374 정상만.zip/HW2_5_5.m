%a) first root
x=[-1:0.1:5.5];
f=-12-21*x+18*x.^2-2.75*x.^3;
plot(x,f);
grid
%b) bisect
fb=@(x) -12-21*x+18*x.^2-2.75*x.^3;
 bisect(fb,-1,0,0.01)
%c) falseposit
falsepos(fb,-1,0,0.01)



%the functions for newton method
f = @(x) exp(0.5*x) - 5 + 5*x;
g = @(x) 0.5*exp(0.5*x) + 5; % derivative of f

[root,ea,iter]=newtraph(f,g,0.7,0.02) %calculation

ea = abs((root - 0.7) / root) * 100 %approximate error
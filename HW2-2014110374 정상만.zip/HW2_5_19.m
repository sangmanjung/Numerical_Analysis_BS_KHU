%The polynomial Cp
Cp=@(T) 0.99403+1.671e-4*T+9.7215e-8*T^2-9.5838e-11*T^3+1.9520e-14*T^4;
ezplot(Cp,[0:1200])
grid

f=@(x) -0.9*x^2+1.7*x+2.5;
%a)fixed point
g=@(x) sqrt(1.8*x+2.5);
fixedpoint(g,5,0.0001)
%b)Newton method
h=@(x) 2*(-0.9)*x+1.7;
newtraph(f,h,0,0.0001)

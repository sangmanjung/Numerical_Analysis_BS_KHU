%a)
%Correct solution at x=1.37
x=1.37;
y=x^3-7*x^2+8*x-0.35;

y
%Chopping each value of x=1.37
a1=chop(x^3,3);
a2=chop(7*x^2,3);
a3=chop(8*x,3);
%Chopped value at x=1.37
y1=a1-a2+a3-0.35;
y1

abs((y-y1)/y);

%b)
y2=((x-7)*x+8)*x-0.35;

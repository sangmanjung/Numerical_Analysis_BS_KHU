%True value of e^-1
f=exp(-1);
%Approximate for e^-1
x=0.25;
x1=1;
h=(x1-x);
%zero-order
f0=exp(-x);
abs((f-f0)/f)
%first-order
f1=exp(-x)-exp(-x)*h;
abs((f-f1)/f)
%second-order
f2=exp(-x)-exp(-x)*h+exp(-x)*(h^2/2);
abs((f-f2)/f)
%third-order
f3=exp(-x)-exp(-x)*h+exp(-x)*(h^2/2)-exp(-x)*(h^3/factorial(3));
abs((f-f3)/f)

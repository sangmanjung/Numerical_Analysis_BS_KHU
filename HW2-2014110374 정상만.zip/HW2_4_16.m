%antiderivative g
x=2;
f=25*x^3-6*x^2+7*x-88;
%derivative of f in 4.13
g=75*x^2-12*x+7;
%the points of finite divied differences
h=0.25;
x0=x-h;
x1=x+h;
f0=25*x0^3-6*x0^2+7*x0-88;
f1=25*x1^3-6*x1^2+7*x1-88;
%forward
ff=(f1-x)/h
ef=abs(g-ff)
%backward
fd=(g-f0)/h
ed=abs(g-fd)
%centered
fc=(f1-f0)/h
ec=abs(g-fc)

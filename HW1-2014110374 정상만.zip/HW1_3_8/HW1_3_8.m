function grade = HW1_3_8(score)
if (90<=score) && (score<=100)
    grade='A';
elseif (80<=score) && (score<90)
    grade='B';
elseif (70<=score) && (score<80)
    grade='C';
elseif (60<=score) && (score<70)
    grade='D';
else
    if (0<=score) && (score<60)
        grade='F';
    else
        grade='Error!';
    end
end
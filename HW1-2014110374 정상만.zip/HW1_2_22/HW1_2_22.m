t=[0:1/16:100];
x=sin(t).*(exp(cos(t))-2.*cos(4.*t)-sin(t/12).^5);
y=cos(t).*(exp(cos(t))-2.*cos(4.*t)-sin(t/12).^5);
z=t;
subplot(2,1,1); plot(z,x,z,y,':');
xlabel('t-axis');
ylabel('x or y axis');
title('Parameterization of the butterfly curve');
legend('x','y')
hold on
subplot(2,1,2);plot(x,y);
xlabel('x-axis');
ylabel('y-axis');
title('Butterfly curve')
axis square
hold off

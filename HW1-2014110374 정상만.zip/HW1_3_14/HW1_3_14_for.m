k=0;
for i=-5:1:50
    k=k+1;
    t(k)=i;
    v(k)=HW1_3_14(t(k));
end
plot(t,v)

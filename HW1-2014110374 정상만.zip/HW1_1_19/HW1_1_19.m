% Given constants
cd=0.25;
m=68.1;
g=9.81;
%The Euler method of a velocity
%dt=1
v0=0;
v1=v0+(g-(cd/m)*v0^2);
v2=v1+(g-(cd/m)*v1^2);
v3=v2+(g-(cd/m)*v2^2);
v4=v3+(g-(cd/m)*v3^2);
v5=v4+(g-(cd/m)*v4^2);
v6=v5+(g-(cd/m)*v5^2);
v7=v6+(g-(cd/m)*v6^2);
v8=v7+(g-(cd/m)*v7^2);
v9=v8+(g-(cd/m)*v8^2);
v10=v9+(g-(cd/m)*v9^2);
%final result of velocity
V=[v0 v2 v4 v6 v8 v10]';
%Time
t=0:2:10;
%Euler method of distance
%dt=1
x0=0;
x1=x0+v0;
x2=x1+v1;
x3=x2+v2;
x4=x3+v3;
x5=x4+v4;
x6=x5+v5;
x7=x6+v6;
x8=x7+v7;
x9=x8+v8;
x10=x9+v9;
%final result of distance
X=[x0 x2 x4 x6 x8 x10]';
%Graph of distance & velocity
subplot(1,2,1);plot(t,X,'r-*');
xlabel('Time');
ylabel('Distance');
title('Distance versus time');
axis square
subplot(1,2,2);plot(t,V,'b-o');
xlabel('Time');
ylabel('Velocity');
title('Velocity versus time');
axis square
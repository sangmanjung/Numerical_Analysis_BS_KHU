c0=100;
k=0.175;
M=(1-k)*0.1;
c1=c0*M;
c2=c1*M;
c3=c2*M;
c4=c3*M;
c5=c4*M;
c6=c5*M;
c7=c6*M;
c8=c7*M;
c9=c8*M;
c10=c9*M;

t=[0:0.1:1];
C=[c0 c1 c2 c3 c4 c5 c6 c7 c8 c9 c10];
dc=-k.*C;

textbox=[t' C' dc']
slope=(log(c10)-log(c0))/1
plot(t,log(C),'s-b')
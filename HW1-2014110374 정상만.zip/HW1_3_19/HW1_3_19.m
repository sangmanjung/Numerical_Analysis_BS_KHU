function yend = HW1_3_19(dydt,dt,ti,tf,yi,varargin)
t=ti; y=yi; h=dt;
while (1)
    if t+dt>tf, h=tf-t; end
    y=y+dydt(y,varargin{:})*h;
    t=t+h;
    if t>=tf, break, end
end
yend=y;

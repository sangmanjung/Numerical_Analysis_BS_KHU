x=linspace(0,3*pi/2);
y=cos(x);
y_mac=1-x.^2/2+x.^4/factorial(4)-x.^6/factorial(6)+x.^8/factorial(8);
plot(x,y,x,y_mac,':')

